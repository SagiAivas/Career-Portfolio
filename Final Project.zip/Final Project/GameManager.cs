﻿internal class GameManager
{
    
}

