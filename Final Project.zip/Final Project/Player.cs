﻿internal class Player
{
    public int MaxHp = 45;
    public int Damage = 3;
    public int CurrentHp = 45;
    public int Shield = 5;
    #region properties
    public string Name { get; set; }
    public bool IsDead { get { return CurrentHp <= 0; } }
    #endregion
    private const float DEFEND_CHANCE = 0.55f;
    #region constructor
    public Player(string name, int maxHp, int currentHp, int shield, int damage)
    {
        Damage = damage;
        Name = name;
        MaxHp = maxHp;
        CurrentHp = currentHp;
        Shield = shield;
    }
    #endregion
    public void Heal()
    {
        int Heal = Random.Shared.Next(4, 8);
        CurrentHp += Heal;
        if (CurrentHp > MaxHp)
        {
            Console.WriteLine("Your current hp cannot be greater than your max hp");
            CurrentHp = MaxHp;
            Console.WriteLine("Your current hp is: " + CurrentHp);
        }
        else
        {
            Console.WriteLine("You healed by " + Heal);
        }
    }
    public void UpgradeShield()
    {
        int upgradeShield = Random.Shared.Next(2, 4);
        Shield += upgradeShield;
        if (Shield > 10)
        {
            Console.WriteLine(" Your shield cannot be greater than 10!");
            Shield = 10;
            Console.WriteLine($"Your shield is: {Shield}. ");
        }
        else
        {
            Console.WriteLine($"Your shield has been improved by: {upgradeShield}. ");
        }
    }
    public void TakeDamage(Enemy enemy)
    {
        int hitChance = Random.Shared.Next(0, 2);
        if (hitChance == 0)
        {
            Console.WriteLine("The hit chance saved you from the enemy's attack!");
        }
        else
        {
            enemy.Damage = Random.Shared.Next(3, 5);
            Shield -= enemy.Damage;
            if (Shield < 0)
            {
                CurrentHp += Shield;
                Shield = 0;
            }
            Console.WriteLine($"The enemy hit you with {enemy.Damage} damage.");
        }
    }
    public void Defence(Enemy enemy)
    {
        var defendChanceValue = Random.Shared.NextDouble();
        if (defendChanceValue > DEFEND_CHANCE)
        {
            enemy.Damage = Random.Shared.Next(1, 2);
            Shield -= enemy.Damage;
            if (Shield < 0)
            {
                CurrentHp += Shield;
                Shield = 0;
            }
            Console.WriteLine($"You just defended some of the attack!");
            Console.WriteLine($"enemy only hitted with {enemy.Damage} damage.");
        }
        else if (defendChanceValue <= DEFEND_CHANCE)
        {
            Console.WriteLine("You failed to defend against the attack");
        }
    }
    public void CriticalHits(Enemy enemy)
    {
        double critHits = Random.Shared.NextDouble();
        if (critHits > 0.77)
        {
            Damage += 2;
            enemy.Shield -= Damage;
            if (enemy.Shield < 0)
            {
                enemy.CurrentHp += enemy.Shield;
                enemy.Shield = 0;
            }
            Console.WriteLine($"You hitted with a critical hit! took from the enemy {Damage} hp. ");
        }
    }
    public void Attack(Enemy enemy)
    {
        enemy.EnemyTakeDamage(this);
    }
}
