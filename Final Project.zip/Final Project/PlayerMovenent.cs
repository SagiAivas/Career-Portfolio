﻿internal class PlayerMovenent
{
    public EnemyManager EnemyManager = new EnemyManager();
    private string _player = "+";
    private static int _x = 3;
    private static int _y = 1;
    public Player Player;
    public static int X { get { return _x; } }
    public static int Y { get { return _y; } }
    public void PlayerMovement()
    {
        int newX = _x;
        int newY = _y;
        ConsoleKeyInfo keyInfo;
        keyInfo = Console.ReadKey(true);
        Console.SetCursorPosition(_x, _y);
        Console.Write(" ");
        if (LevelManager.CurrentMap[newX, newY] == '#')
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetCursorPosition(newX, newY);
            Console.Write("#");
            Console.ForegroundColor = ConsoleColor.White;
        }
        switch (keyInfo.Key)
        {
            case ConsoleKey.W:
                newY = _y - 1;
                break;
            case ConsoleKey.S:
                newY = _y + 1;
                break;
            case ConsoleKey.A:
                newX = _x - 1;
                break;
            case ConsoleKey.D:
                newX = _x + 1;
                break;
            default:
                break;
        }
        if (!CanMove(newX, newY))
        {
            Console.SetCursorPosition(54, 5);
            Console.WriteLine("You cannot move!");

            Task.Delay(2000).ContinueWith(_ =>
            {
                Console.SetCursorPosition(54, 5);
                Console.Write(new string(' ', "You cannot move!".Length));
            });
        }
        if (LevelManager.CurrentMap[newX, newY] == '┼')
        {
            if (LevelManager.CurrentMapIndex != 10)
            {
                NextLevel();
                EnemiesPerLevel();
                ResetCourser();
                UI_Class.UiFence();
                UI_Class.PlayerData();
                newX = _x;
                newY = _y;
            }
        }
        if (LevelManager.CurrentMap[newX, newY] == '#')
        {
            Traps.Trap();
        }
        if (LevelManager.CurrentMap[newX, newY] == '$')
        {
            Rewards.Reward();
            LevelManager.CurrentMap[newX, newY] = ' ';
        }
        //open the gate
        if (LevelManager.CurrentMap[newX, newY] == 'O' ||
            LevelManager.CurrentMap[newX, newY] == 'P' ||
            LevelManager.CurrentMap[newX, newY] == 'E' ||
            LevelManager.CurrentMap[newX, newY] == 'N')
        {
            if (LevelManager.CurrentMapIndex == 1)
            {
                OpenGatePrinter();
                Console.SetCursorPosition(24, 16);
                LevelManager.CurrentMap[24, 16] = ' ';
                Console.Write(" ");
            }
            if (LevelManager.CurrentMapIndex == 2)
            {
                OpenGatePrinter();
                Console.SetCursorPosition(9, 15);
                LevelManager.CurrentMap[10, 20] = ' ';
                Console.Write(" ");
            }
            if (LevelManager.CurrentMapIndex == 4)
            {
                OpenGatePrinter();
                Console.SetCursorPosition(16, 23);
                LevelManager.CurrentMap[16, 23] = ' ';
                Console.Write(" ");
            }
            if (LevelManager.CurrentMapIndex == 9)
            {
                OpenGatePrinter();
                Console.SetCursorPosition(43, 25);
                LevelManager.CurrentMap[43, 25] = ' ';
                Console.Write(" ");
            }
        }
        foreach (Enemy enemy in EnemyManager.Enemies)
        {
            if (enemy.X == X && enemy.Y == Y)
            {
                Console.Clear();
                Console.SetCursorPosition(0, 10);
                Battle battle = new Battle(Program.player1, enemy);
                EnemiesAfterDeath();
                break;
            }
        }
        if (LevelManager.CurrentMap[newX, newY] == '◄' ||
            LevelManager.CurrentMap[newX, newY] == '►' ||
            LevelManager.CurrentMap[newX, newY] == '▲' ||
            LevelManager.CurrentMap[newX, newY] == '▼')
        {
            if (Program.player1.Shield >= 2)
            {
                Program.player1.Shield -= 2;
            }
            else
            {
                Program.player1.CurrentHp += Program.player1.Shield;
                Program.player1.Shield = 0;
            }
            Program.player1.CurrentHp -= 2;
            UI_Class.RefreshUI();
            Console.SetCursorPosition(54, 7);
            Console.WriteLine($"You just hitted a spike!");
            UI_Class.RefreshUI();
            Task.Delay(2000).ContinueWith(_ =>
            {
                Console.SetCursorPosition(54, 7);
                Console.Write(new string(' ', $"You just hitted a spike!".Length));
            });
        }
        if (CanMove(newX, newY))
        {
            _x = newX;
            _y = newY;
        }
        Console.SetCursorPosition(_x, _y);
        Console.WriteLine(_player);
    }
    public bool CanMove(int x, int y)
    {
        if ((x < 0 || x >= LevelManager.CurrentMap.GetLength(0) ||
            y < 0 || y >= LevelManager.CurrentMap.GetLength(1)) ||
            LevelManager.CurrentMap[x, y] != ' ' &&
            LevelManager.CurrentMap[x, y] != '#' &&
            LevelManager.CurrentMap[x, y] != '$' &&
            LevelManager.CurrentMap[x, y] != '&')
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public void NextLevel()
    {
        Console.Clear();
        LevelManager.NextLevel();
        ResetCourser();
    }
    public void ResetCourser()
    {
        _x = 3;
        _y = 1;
    }
    private static void OpenGatePrinter()
    {
        Console.SetCursorPosition(54, 8);
        Console.WriteLine("You just opened a gate!");
        Task.Delay(2000).ContinueWith(_ =>
        {
            Console.SetCursorPosition(54, 8);
            Console.Write(new string(' ', "You just opened a gate!".Length));
        });
    }
    private void EnemiesPerLevel()
    {
        if (LevelManager.CurrentMapIndex < 1)
        {
            EnemyManager.CreateNewEnemies();
        }
        else if (LevelManager.CurrentMapIndex == 1)
        {
            EnemyManager.CreateNewEnemies();
        }
        else if
            (LevelManager.CurrentMapIndex == 2 ||
            LevelManager.CurrentMapIndex == 3 ||
            LevelManager.CurrentMapIndex == 4 ||
            LevelManager.CurrentMapIndex == 5 ||
            LevelManager.CurrentMapIndex == 6 ||
            LevelManager.CurrentMapIndex == 7)
        {
            EnemyManager.CreateNewEnemies();
            EnemyManager.CreateNewEnemies();
        }
        else if (LevelManager.CurrentMapIndex == 8 ||
                 LevelManager.CurrentMapIndex == 9)
        {
            EnemyManager.CreateNewEnemies();
            EnemyManager.CreateNewEnemies();
            EnemyManager.CreateNewEnemies();
        }
    }
    private void EnemiesAfterDeath()
    {
        if (LevelManager.CurrentMapIndex == 0 ||
            LevelManager.CurrentMapIndex == 1)
        {
        }
        else if
            (LevelManager.CurrentMapIndex == 2 ||
            LevelManager.CurrentMapIndex == 3 ||
            LevelManager.CurrentMapIndex == 4 ||
            LevelManager.CurrentMapIndex == 5 ||
            LevelManager.CurrentMapIndex == 6 ||
            LevelManager.CurrentMapIndex == 7)
        {
            EnemyManager.CreateNewEnemies();
        }
        else if (LevelManager.CurrentMapIndex == 8 ||
                 LevelManager.CurrentMapIndex == 9)
        {
            EnemyManager.CreateNewEnemies();
            EnemyManager.CreateNewEnemies();
        }

    }
}