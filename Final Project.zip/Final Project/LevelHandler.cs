﻿public static class LevelHandler
{
    public static char[,] LevelReader(string filePath)
    {
        string[] lines = File.ReadAllLines(filePath, System.Text.Encoding.UTF8);
        var output = new char[lines[0].Length, lines.Length];
        for (int i = 0; i < lines[0].Length; i++)
        {
            for (int j = 0; j < lines.Length; j++)
            {
                output[i, j] = lines[j][i];
            }
        }
        return output;
    }
    public static void MapPrinter(char[,] level)
    {
        for (int i = 0; i < level.GetLength(0); i++)
        {
            for (int j = 0; j < level.GetLength(1); j++)
            {
                Console.SetCursorPosition(i, j);
                if (level[i, j] == '0')
                {
                    Console.ForegroundColor = ConsoleColor.Black;
                }
                if (level[i, j] == '◄' || level[i, j] == '▲' || level[i, j] == '▼' || level[i, j] == '►')
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                if (level[i, j] == '┼')
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }
                if (level[i, j] == Traps.TrapChar && Traps.IsHidden == true)
                {
                    Console.ForegroundColor = ConsoleColor.Black;
                }
                else if (level[i, j] == Traps.TrapChar)
                {
                    Console.SetCursorPosition(i, j);
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                if (level[i, j] == '$')
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }
                Console.Write(level[i, j]);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    }
}