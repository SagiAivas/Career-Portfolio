﻿internal class UI_Class
{
    public Enemy Enemy { get; }
    public static int indexLight = 1;
    public UI_Class(Enemy enemy)
    {
        Enemy = enemy;
    }
    public static void UiFence()
    {
        int c = 0;
        for (int i = 0; i <= 28; i++)
        {
            Console.SetCursorPosition(52, c);
            Console.Write("│\n");
            c++;
        }
    }
    public static void PlayerData()
    {
        Console.SetCursorPosition(54, 0);
        Console.Write($"Level: ");
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine($"{LevelManager.CurrentMapIndex + 1}");
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(54, 1);
        Console.Write($"Your Max Hp Is: ");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.SetCursorPosition(70, 1);
        Console.WriteLine(Program.player1.MaxHp);
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(54, 2);
        Console.Write($"Your Current Hp Is: ");
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.SetCursorPosition(74, 2);
        Console.WriteLine(Program.player1.CurrentHp);
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(54, 3);
        Console.Write($"Your Shield Is: ");
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.SetCursorPosition(70, 3);
        Console.WriteLine(Program.player1.Shield);
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(54, 4);
        Console.Write($"Your Damage Is: ");
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.SetCursorPosition(70, 4);
        Console.WriteLine(Program.player1.Damage);
        Console.ForegroundColor = ConsoleColor.White;
    }
    public static void RefreshUI()
    {
        for (int i = 54; i < 78; i++)
        {
            for (int j = 0; j <= 5; j++)
            {
                Console.SetCursorPosition(i, j);
                Console.Write(' ');
            }
        }
        PlayerData();
    }
    public void RefreshEnemyUI()
    {
        for (int i = 78; i < 102; i++)
        {
            for (int j = 0; j <= 5; j++)
            {
                Console.SetCursorPosition(i, j);
                Console.Write(' ');
            }
        }
        EnemyData();
    }
    public static void PrintOptions()
    {
        Console.SetCursorPosition(0, 2);
        Console.WriteLine("1 - Attack");
        Console.WriteLine("2 - Defend");
        Console.WriteLine("3 - Heal");
        Console.WriteLine("4 - Upgrade Shield");
    }
    public void EnemyData()
    {
        Console.SetCursorPosition(83, 0);
        Console.Write($"Enemy Max Hp Is: ");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.SetCursorPosition(100, 0);
        Console.WriteLine(Enemy.MaxHp);
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(83, 1);
        Console.Write($"Enemy Current Hp Is: ");
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.SetCursorPosition(105, 1);
        Console.WriteLine(Enemy.CurrentHp);
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(83, 2);
        Console.Write($"Enemy Shield Is: ");
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.SetCursorPosition(100, 2);
        Console.WriteLine(Enemy.Shield);
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(83, 3);
        Console.Write($"Enemy Damage Is: ");
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.SetCursorPosition(100, 3);
        Console.WriteLine(Enemy.Damage);
        Console.ForegroundColor = ConsoleColor.White;
    }
    public void RefreshBattle()
    {
        Console.SetCursorPosition(0, 12);
        Console.WriteLine("Press any key to continue");
        Console.ReadKey();
        Console.Clear();
        UiFence();
        PlayerData();
        EnemyData();
    }
    public static void Menu()
    {
        Console.WriteLine("Hello Hero, Welcome To the Dungeon Crawler Game!");
        Console.WriteLine("Use W and S and Enter for chosing");
        while (true)
        {
            Console.SetCursorPosition(0, 3);
            if (indexLight == 1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            Console.WriteLine("                Start Game");
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(0, 5);
            if (indexLight == 2)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            Console.WriteLine("               How to play");
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(0, 7);
            if (indexLight == 3)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            Console.WriteLine("                 Credits");
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(0, 9);
            if (indexLight == 4)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            Console.WriteLine("                   Exit");
            Console.ForegroundColor = ConsoleColor.White;
            ConsoleKey keyInput = MenuInput();
            ChosingInMenu(keyInput);
        }
    }

    public static ConsoleKey MenuInput()
    {
        ConsoleKeyInfo key = Console.ReadKey();
        Console.SetCursorPosition(0, 10);
        Console.WriteLine(" ");
        if (key.Key == ConsoleKey.S && indexLight + 1 < 5)
        {
            indexLight++;
        }
        else if (key.Key == ConsoleKey.W && indexLight - 1 > 0)
        {
            indexLight--;
        }
        return key.Key;
    }

    public static void ChosingInMenu(ConsoleKey keyChose)
    {
        if (indexLight == 1 && keyChose == ConsoleKey.Enter)
        {
            Console.Clear();
            Program.StartGame();
        }
        else if (indexLight == 2 && keyChose == ConsoleKey.Enter)
        {
            Console.Clear();
            Console.WriteLine("How To Play:");
            Console.WriteLine("Use WASD in order to move in the map");
            Console.WriteLine("use 1,2,3,4 inside the battle in order to execute your abilities");
            Console.WriteLine("go to this - ┼┼ sign in order to move to the next level");
            Console.SetCursorPosition(0, 10);
            Console.WriteLine("Press any key for returning to the menu");
            Console.ReadKey(true);
            Console.Clear();
            Menu();
        }
        else if (indexLight == 3 && keyChose == ConsoleKey.Enter)
        {
            Console.Clear();
            Console.Write("The Game Has Been Made By: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Sagi Aivas");
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(0, 10);
            Console.WriteLine("Press any key for returning to the menu");
            Console.ReadKey(true);
            Console.Clear();
            Menu();
        }
        else if (indexLight == 4 && keyChose == ConsoleKey.Enter)
        {
            Environment.Exit(0);
        }
    }
}

