﻿internal class Battle
{
    UI_Class UI_Class;
    public Turns PlayerTurn;
    public Turns EnemyTurn;
    EnemyManager enemyManager = new EnemyManager();
    public Battle(Player player, Enemy enemy)
    {
        UI_Class = new UI_Class(enemy);
        PlayerTurn = new Turns(player, enemy, UI_Class);
        EnemyTurn = new Turns(enemy, player, UI_Class);
        RunBattle();
    }
    private void RunBattle()
    {
        while (!PlayerTurn.Player.IsDead && !EnemyTurn.Enemy.IsDead)
        {
            UI_Class.UiFence();
            UI_Class.PlayerData();
            UI_Class.EnemyData();
            Console.SetCursorPosition(0, 0);
            Console.WriteLine($"You are fighting against: {EnemyTurn.Enemy.Stuff} {EnemyTurn.Enemy.Name}!");
            Console.WriteLine("Choose Your Next Move:");
            UI_Class.PrintOptions();
            PlayerTurn.GetPlayerInput();
            EnemyTurn.GenerateEnemyInput();
            UI_Class.RefreshEnemyUI();
            UI_Class.RefreshUI();
            UI_Class.RefreshBattle();
        }
        if (EnemyTurn.Enemy.IsDead)
        {
            Console.Clear();
            Console.SetCursorPosition(54, 4);
            Console.WriteLine("Well played, you just killed the enemy!");
            Task.Delay(2000).ContinueWith(_ =>
            {
                Console.SetCursorPosition(54, 4);
                Console.Write(new string(' ', "Well played, you just killed the enemy!".Length));
            });
            foreach (Enemy enemy in EnemyManager.Enemies)
            {
                if (enemy.X == PlayerMovenent.X && enemy.Y == PlayerMovenent.Y)
                {
                    EnemyManager.Enemies.Remove(enemy);
                }
            }
            LevelHandler.MapPrinter(LevelManager.CurrentMap);
            UI_Class.UiFence();
            UI_Class.RefreshUI();
            //rewards or shop
        }
        else
        {
            Console.Clear();
            UI_Class.UiFence();
            UI_Class.RefreshUI();
            Console.SetCursorPosition(0, 0);
            Console.WriteLine($"Loser! You lost to {EnemyTurn.Enemy.Stuff} {EnemyTurn.Enemy.Name}.");
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
            Console.Clear();
            Environment.Exit(0);
        }
    }
}