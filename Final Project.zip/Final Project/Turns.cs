﻿internal class Turns
{
    private UI_Class UI_Class;
    public Player Player { get; }
    public Enemy Enemy { get; }
    public Turns(Player player, Enemy enemy, UI_Class uiClass)
    {
        UI_Class = uiClass;
        Player = player;
        Enemy = enemy;
    }
    public Turns(Enemy enemy, Player player, UI_Class uiClass)
    {
        UI_Class = uiClass;
        Enemy = enemy;
        Player = player;
    }
    public void GetPlayerInput()
    {
        int playerInt;
        UI_Class.PrintOptions();
        while (true)
        {
            string playerInput = Console.ReadLine();
            if (int.TryParse(playerInput, out playerInt))
            {
                if (playerInt >= 1 && playerInt <= 4)
                {
                    break;
                }
            }
            Console.WriteLine("Wrong input!");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
            Console.Clear();
            UI_Class.UiFence();
            UI_Class.PlayerData();
            UI_Class.EnemyData();
            Console.SetCursorPosition(0, 0);
            Console.WriteLine($"You are fighting against: {Enemy.Stuff} {Enemy.Name}!");
            Console.WriteLine("Choose Your Next Move:");
            UI_Class.PrintOptions();
            Console.SetCursorPosition(0, 6);
        }
        ExecuteInput(playerInt);
        if (playerInt != 3 && playerInt != 4)
        {
            GenerateEnemyInput();
        }
    }
    public void GenerateEnemyInput()
    {
        int enemyInput = Random.Shared.Next(1, 3);
        ExecuteEnemyInput(enemyInput);
    }
    public void ExecuteInput(int input)
    {
        switch (input)
        {
            case 1:
                Player.Attack(Enemy);
                break;
            case 2:
                Player.Defence(Enemy);
                break;
            case 3:
                Player.Heal();
                break;
            case 4:
                Player.UpgradeShield();
                break;
            default:
                break;
        }
    }
    public void ExecuteEnemyInput(int input)
    {
        switch (input)
        {
            case 1:
                Enemy.EnemyAttack(Player);
                break;
            case 2:
                Enemy.EnemyDefence(Player);
                break;
            case 3:
                Enemy.EnemyHeal();
                break;
            case 4:
                Enemy.EnemyUpgradeShield();
                break;
            default:
                break;
        }
    }

}
