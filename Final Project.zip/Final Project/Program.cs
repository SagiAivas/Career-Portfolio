﻿class Program
{
    public static Player player1;

    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        UI_Class.Menu();
        StartGame();
    }



    public static void StartGame()
    {
        player1 = new Player("", 45, 45, 5, 3);
        LevelManager levelManager = new LevelManager();
        levelManager.StartLevel(0);
        PlayerMovenent player = new PlayerMovenent();
        EnemyManager enemyManager = new EnemyManager();
        enemyManager.CreateNewEnemies();
        UI_Class.UiFence();
        UI_Class.PlayerData();
        while (player1.CurrentHp > 0)
        {
            player.PlayerMovement();
            enemyManager.UpdateEnemies();
        }
        if (player1.CurrentHp <= 0)
        {
            Console.Clear();
            Console.WriteLine("Haha, You Died !!!");
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }

}