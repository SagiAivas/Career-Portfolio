﻿internal class EnemyManager
{
    //create enemies 
    //spawn enemies
    //track enemies
    private static string[] _stuff = new string[] { "OP", "Horibble", "Ez", "Extreamly Weak", "Giant" };
    private static string[] _enemyName = new string[] { "Goat", "Dragon", "Robot", "Zombie", "Lecturer" };
    public static List<Enemy> Enemies;
    public EnemyManager()
    {
        Enemies = new List<Enemy>();
    }
    public void UpdateEnemies()
    {
        for (int i = 0; i < Enemies.Count; i++)
        {
            Enemies[i].EnemyMovement(PlayerMovenent.X, PlayerMovenent.Y);
        }
    }
    public Enemy CreateNewEnemies()
    {
        if (LevelManager.CurrentMapIndex != 10)
        {
            var position = GetRandomEnemyPosition();//get new position
            string enemyName = _enemyName[Random.Shared.Next(_enemyName.Length)];
            string stuff = _stuff[Random.Shared.Next(_stuff.Length)];
            int hp = Random.Shared.Next(5, 7);
            int shield = Random.Shared.Next(1, 3);
            int damage = Random.Shared.Next(3, 5);
            Enemy enemy = new Enemy(position.Item1, position.Item2, enemyName, stuff, hp, hp, shield, damage);//create new enemy
            //save the new enemy
            Enemies.Add(enemy);
            return enemy;
        }
        return null;
    }
    private Tuple<int, int> GetRandomEnemyPosition()
    {
        while (true)
        {
            int width = LevelManager.CurrentMap.GetLength(0);
            int height = LevelManager.CurrentMap.GetLength(1);
            int x = Random.Shared.Next(0, width);
            int y = Random.Shared.Next(0, height);
            if (LevelManager.CurrentMap[x, y] == ' ' && LevelManager.CurrentMapIndex != 10)
            {
                Tuple<int, int> output = new(x, y);
                return output;
            }
        }
    }
}

