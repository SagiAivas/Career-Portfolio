﻿internal class LevelManager
{
    private string[] _textFiles = new string[]
    {
       Path.Combine("Maps", "Level One.txt"),
       Path.Combine("Maps", "Level Two.txt"),
       Path.Combine("Maps", "Level Three.txt"),
       Path.Combine("Maps", "Level Four.txt"),
       Path.Combine("Maps", "Level Five.txt"),
       Path.Combine("Maps", "Level Six.txt"),
       Path.Combine("Maps", "Level Seven.txt"),
       Path.Combine("Maps", "Level Eight.txt"),
       Path.Combine("Maps", "Level Nine.txt"),
       Path.Combine("Maps", "Level Ten.txt"),
    };

    private static char[,] _currentMap;
    private static int _currentMapIndex = 0;
    private static List<char[,]> _maps = new List<char[,]>();

    public LevelManager()
    {
        for (int i = 0; i < _textFiles.Length; i++)
        {
            _maps.Add(LevelHandler.LevelReader(_textFiles[i]));
        }
    }

    public static char[,] CurrentMap { get => _currentMap; }
    public static int CurrentMapIndex { get => _currentMapIndex; }

    public void StartLevel(int levelIndex)
    {
        _currentMapIndex = levelIndex;
        _currentMap = _maps[levelIndex];
        LevelHandler.MapPrinter(_currentMap);
    }

    public static void NextLevel()
    {
        _currentMapIndex++;
        if (_currentMapIndex >= _maps.Count)
        {
            Console.Clear();
            string endFilePath = Path.Combine("Maps", "End.txt");
            string endMessage = File.ReadAllText(endFilePath);
            Console.WriteLine(endMessage);
            Console.SetCursorPosition(0, 0);
            Console.WriteLine("Well Played! You Just Finished The Game!!!");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
            Environment.Exit(0);
        }
        else
        {
            _currentMap = _maps[_currentMapIndex];
            LevelHandler.MapPrinter(_currentMap);
        }
    }
}