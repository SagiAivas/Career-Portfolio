﻿internal class Traps
{
    public static bool IsHidden = true;
    public static char TrapChar = '#';
    public static void Trap()
    {
        Program.player1.Shield -= 2;
        if (Program.player1.Shield < 0)
        {
            Program.player1.CurrentHp += Program.player1.Shield;
            Program.player1.Shield = 0;
        }
        Console.SetCursorPosition(54, 9);
        Console.WriteLine($"You just hitted a trap! -2 hp");
        UI_Class.RefreshUI();
        Task.Delay(3000).ContinueWith(_ =>
        {
            Console.SetCursorPosition(54, 9);
            Console.Write(new string(' ', $"You just hitted a trap! -2 hp".Length));
        });
    }
}

