﻿internal class Rewards
{
    public static char RewardChar = '$';
    private static bool _choises = false;
    public static void Reward()
    {
        Console.Clear();
        UI_Class.UiFence();
        UI_Class.RefreshUI();
        Console.SetCursorPosition(0, 0);
        Console.WriteLine("Hello Hero, Choose Your Reward:");
        Console.WriteLine("1 - Increase Your Current Hp");
        Console.WriteLine("2 - Increase Your Shield");
        Console.WriteLine("3 - Increase Your Max Hp");
        string choise = Console.ReadLine();
        int choiseInt = 0;
        if (int.TryParse(choise, out choiseInt)) ;
        {
            while (choiseInt != 1 && choiseInt != 2 && choiseInt != 3)
            {
                Console.Clear();
                Console.WriteLine("Wrong Input, Please Choose Again:");
                Console.WriteLine("1 - Increase Your Current Hp");
                Console.WriteLine("2 - Increase Your Shield");
                Console.WriteLine("3 - Increase Your Max Hp");
                choise = Console.ReadLine();
                if (int.TryParse(choise, out choiseInt)) ;
            }
        }
        while (!_choises)
        {
            switch (choiseInt)
            {
                case 1:
                    if (Program.player1.CurrentHp >= Program.player1.MaxHp)
                    {
                        Console.WriteLine("Your current hp cant be higher than your max hp");
                        Console.WriteLine("Please choose again:");
                        choise = Console.ReadLine();
                        if (int.TryParse(choise, out choiseInt)) ;
                    }
                    else
                    {
                        int hp = Random.Shared.Next(3, 6);
                        if (Program.player1.CurrentHp + hp > Program.player1.MaxHp)
                        {
                            Console.WriteLine("Your current hp cant be higher than your max hp");
                            Console.WriteLine("Please choose again:");
                            choise = Console.ReadLine();
                            if (int.TryParse(choise, out choiseInt)) ;
                        }
                        Console.WriteLine($"You upgraded your currnt hp by: {hp}.");
                        Program.player1.CurrentHp += hp;
                        _choises = true;
                        UI_Class.RefreshUI();
                    }
                    break;
                case 2:
                    int shield = Random.Shared.Next(3, 4);
                    Console.WriteLine($"You upgraded your shield by: {shield}.");
                    Program.player1.Shield += shield;
                    _choises = true;
                    UI_Class.RefreshUI();
                    break;
                case 3:
                    int maxHp = Random.Shared.Next(3, 6);
                    Console.WriteLine($"You upgraded your max hp by: {maxHp}.");
                    Program.player1.MaxHp += maxHp;
                    _choises = true;
                    UI_Class.RefreshUI();
                    break;
                default:
                    break;
            }
        }
        Console.SetCursorPosition(0, 20);
        Console.WriteLine("Press any key to continue");
        Console.ReadKey();
        Console.Clear();
        LevelHandler.MapPrinter(LevelManager.CurrentMap);
        UI_Class.UiFence();
        UI_Class.RefreshUI();
        _choises = false;
    }
}

