﻿class Enemy
{
    public int MaxHp = 0;
    public int Damage = 0;
    public int CurrentHp = 0;
    public int Shield = 0;
    private int hitChance;
    #region properties
    public string Name { get; set; }
    public string Stuff { get; set; }
    public bool IsDead { get { return CurrentHp <= 0; } }
    #endregion
    private const float DEFEND_CHANCE = 0.77f;
    private string _enemy = "&";
    public int X;
    public int Y;
    public Enemy(int X, int Y, string name, string stuff, int maxHp, int currentHp, int shield, int damage)
    {
        Damage = damage;
        Name = name;
        Stuff = stuff;
        MaxHp = maxHp;
        CurrentHp = currentHp;
        Shield = shield;
        this.X = X;
        this.Y = Y;
        DrawEnemy();
    }
    public void EnemyMovement(int playerX, int playerY)
    {
        if (!IsPlayerNear())
        {
            RandomMovement();
            return;
        }
        int newX = 0;
        int newY = 0;
        if (X < playerX)
        {
            newX = X + 1;
        }
        else
        {
            newX = X - 1;
        }
        if (Y < playerY)
        {
            newY = Y + 1;
        }
        else
        {
            newY = Y - 1;
        }
        if (CanMove(newX, newY))
        {
            Console.SetCursorPosition(X, Y);
            Console.Write(" ");
            X = newX;
            Y = newY;
            Console.SetCursorPosition(X, Y);
            Console.WriteLine(_enemy);
            DrawEnemy();
        }
        else
        {
            RandomMovement();
            return;
        }
    }
    public void RandomMovement()
    {
        int direction = Random.Shared.Next(0, 4);
        int newX = X;
        int newY = Y;
        switch (direction)
        {
            case 0:
                newY = Y - 1;
                break;
            case 1:
                newX = X + 1;
                break;
            case 2:
                newY = Y + 1;
                break;
            case 3:
                newX = X - 1;
                break;
        }
        if (CanMove(newX, newY))
        {
            Console.SetCursorPosition(X, Y);
            Console.Write(" ");
            X = newX;
            Y = newY;
            Console.SetCursorPosition(X, Y);
            Console.WriteLine(_enemy);
            DrawEnemy();
        }
    }
    public bool CanMove(int x, int y)
    {
        if (x < 0 || x >= LevelManager.CurrentMap.GetLength(0) ||
            y < 0 || y >= LevelManager.CurrentMap.GetLength(1) ||
            LevelManager.CurrentMap[x, y] != ' ')
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public bool IsPlayerNear()
    {
        int playerX = PlayerMovenent.X;
        int playerY = PlayerMovenent.Y;
        return playerX <= X + 4 && playerX >= X - 4 && playerY <= Y + 4 && playerY >= Y - 4;
    }
    public void EnemyHeal()
    {
        int Heal = Random.Shared.Next(1, 4);
        CurrentHp += Heal;
        if (CurrentHp > MaxHp)
        {
            CurrentHp = MaxHp;
        }
        Console.WriteLine("Enemy has healed by " + Heal);
    }
    public void EnemyUpgradeShield()
    {
        Shield = Random.Shared.Next(1, 3);
        Console.WriteLine($"Enemy shield has been improved by {Shield}. ");
    }
    public void EnemyTakeDamage(Player player)
    {
        hitChance = Random.Shared.Next(0, 6);
        if (hitChance == 0)
        {
            Console.WriteLine("The enemy just dodged your attack!");
        }
        else
        {
            Shield -= player.Damage;
            if (Shield < 0)
            {
                CurrentHp += Shield;
                Shield = 0;
            }
            Console.WriteLine($"You hit the enemy with {player.Damage} damage.");
        }
    }
    public void EnemyDefence(Player player)
    {
        if (hitChance != 0)
        {
            var defendChanceValue = Random.Shared.NextDouble();
            if (defendChanceValue > DEFEND_CHANCE)
            {
                player.Damage = Random.Shared.Next(1, 3);
                Shield -= Program.player1.Damage;
                if (Shield < 0)
                {
                    CurrentHp += Shield;
                    Shield = 0;
                    player.Damage = 3;
                }
                Console.WriteLine($"The enemy blocked some of your attack,");
                Console.WriteLine($"You hitted with {player.Damage} damage.");
            }
            else
            {
                Console.WriteLine("The enemy failed to defend against your attack.");
                Console.WriteLine($"You hitted with {player.Damage} damage.");
            }
        }
    }
    public void CriticalHits(Player player)
    {
        double critHits = Random.Shared.NextDouble();
        if (critHits > 0.77)
        {
            Damage = Random.Shared.Next(5, 7);
            Program.player1.Shield -= Damage;
            if (Program.player1.Damage < 0)
            {
                player.CurrentHp += player.Shield;
                player.Shield = 0;
            }
            Console.WriteLine($"The enemy landed a critical hit on you, dealing {Damage} damage.");
        }
    }
    private void DrawEnemy()
    {
        Console.SetCursorPosition(X, Y);
        Console.ForegroundColor = ConsoleColor.DarkRed; 
        Console.WriteLine(_enemy);
        Console.ForegroundColor = ConsoleColor.White; 
    }
    public void EnemyAttack(Player player)
    {
        player.TakeDamage(this);
    }
}